class UnstableRenderer extends GridRenderer {
	constructor() {
		super();
	}

	async drawBoard() {
		const dark = await this.loadImage("img/darkcell.png");
		const light = await this.loadImage("img/lightcell.png");
		for (let row = 0; row < 8; row++) {
			for (let col = 0; col < 8; col++) {
				this.drawImage(location2id(col, row), (row+col)%2 ? dark:light);
			}
		}
	}

	async render(model) {
		this.setRect(50, 50, 400, 400);
		this.setDimensions(8, 8);
		this.clear();
		await this.drawBoard();
		this.drawGrid();
	}
}