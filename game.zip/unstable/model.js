class UnstableModel extends Model {
	constructor() {
		super();
	}
}